package com.example.gorev_takip_uygulamasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
